import send_methods as sm
import variables as v


answers = sm.get_answers(v.answers_source)

final_dict = sm.get_final_dict(
    answers=answers,
    fname=v.fname, lname=v.lname, email=v.email)

response = sm.send_answers(
    'https://httpbin.org/post',
    # v.post_answers_uri,
    final_dict,
    v.headers)

is_zipped = sm.zip_files(
    v.zip_file,
    v.files)

response.request.headers
response
